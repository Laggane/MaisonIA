# MaisonIA

Application Flask + HTML + Docker Compose.

## Lancement
```bash
docker-compose up -d --build
```